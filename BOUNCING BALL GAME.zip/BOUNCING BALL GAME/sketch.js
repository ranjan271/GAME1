var box,canvas;
var ob1,ob2;

function setup()
{

    createCanvas(400,400);

    box=createSprite(200,380,20,20);
    box.shapeColor="lime";

    
    ob3=createSprite(200,80,40,5);
    ob3.shapeColor="blue";
    ob3.velocityX=-12;
    ob5=createSprite(200,80,40,5);
    ob5.shapeColor="blue";
    ob5.velocityX=12;
    
    
    ob1=createSprite(0,160,80,5);
    ob1.shapeColor="blue";
    ob1.velocityX=8;
    ob7=createSprite(400,160,80,5);
    ob7.shapeColor="blue";
    ob7.velocityX=-8;
    
    ob2=createSprite(200,240,120,5);
    ob2.shapeColor="blue";
    ob2.velocityX= -5;
    ob6=createSprite(200,240,120,5);
    ob6.shapeColor="blue";
    ob6.velocityX= 5;


    ob4=createSprite(0,320,160,5);
    ob4.shapeColor="blue";
    ob4.velocityX=4;
    ob8=createSprite(400,320,160,5);
    ob8.shapeColor="blue";
    ob8.velocityX=-4;


    //top 

    ob9=createSprite(0,0,320,10);
    ob9.shapeColor="blue";
    
    ob10=createSprite(400,0,320,10);
    ob10.shapeColor="blue";

    ob11=createSprite(200,0,80,10);
    ob11.shapeColor="lime";


    //sides
    ob12=createSprite(0,40,10,70);
    ob12.shapeColor="blue";
    
    ob13=createSprite(400,40,10,70);
    ob13.shapeColor="blue";

    ob14=createSprite(0,400,10,150);
    ob14.shapeColor="blue";
    
    ob15=createSprite(400,400,10,150);
    ob15.shapeColor="blue";





    edges = createEdgeSprites();

}

function draw()
{
    background("black");

    ob1.bounceOff(edges);
    ob2.bounceOff(edges);
    ob3.bounceOff(edges);
    ob4.bounceOff(edges);
    ob5.bounceOff(edges);
    ob6.bounceOff(edges);
    ob7.bounceOff(edges);
    ob8.bounceOff(edges);
    box.bounceOff(edges);
    

    if(keyDown(DOWN_ARROW)){

        box.velocityX=0;
        box.velocityY=3;
    
    }
    
    if(keyDown(RIGHT_ARROW)){

        box.velocityX=3;
        box.velocityY=0;
    
    }
    
    if(keyDown(UP_ARROW)){

        box.velocityX=0;
        box.velocityY=-3;
    
    }
    
    if(keyDown(LEFT_ARROW)){

        box.velocityX=-3;
        box.velocityY=0;
    
    }
    if(box.isTouching(ob1) || box.isTouching(ob2) || box.isTouching(ob3)
   || box.isTouching(ob4) || box.isTouching(ob5)||box.isTouching(ob6) ||box.isTouching(ob7)
   || box.isTouching(ob8) || box.isTouching(ob9) || box.isTouching(ob10) ||
   box.isTouching(ob12) || box.isTouching(ob13) || box.isTouching(ob14) || box.isTouching(ob15))
   {
    box.velocityX=0;
    box.velocityY=0;
    ob1.velocityX=0;
    ob2.velocityX=0;
    ob3.velocityX=0;
    ob4.velocityX=0;
    ob5.velocityX=0;
    ob6.velocityX=0;
    ob7.velocityX=0;
    ob8.velocityX=0;
    fill("lime");
    textSize(25);
    text("TRY TILL U WIN....!!!",150,150);
   } 

   if(box.isTouching(ob11))
   {
    box.velocityX=0;
    box.velocityY=0;
    ob1.velocityX=0;
    ob2.velocityX=0;
    ob3.velocityX=0;
    ob4.velocityX=0;
    ob5.velocityX=0;
    ob6.velocityX=0;
    ob7.velocityX=0;
    ob8.velocityX=0;
    fill("lime");
    textSize(25);
    text("PLAY NEXT LEVEL",150,150);
   }

    drawSprites();
}